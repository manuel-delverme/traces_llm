TOKEN_CONTEXT_LEN = 18
POINTS_IN_MOTOR_SEQUENCE = 64
IMAGE_SIDE = 28

early_stopping_patience = 32

learning_rate = 0.0006247650066162154
# learning_rate = 1e-3  # 3e-5
batch_size = 32
training_hours = 1

num_layers = 1
hidden_size = 128
